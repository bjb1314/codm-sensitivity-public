import React from "react";
import { createRoot } from "react-dom/client";
import { SensApp } from "../src/components/sens/SensApp";
import "../src/styles.css";
createRoot(document.getElementById("root")!).render(<SensApp />);
