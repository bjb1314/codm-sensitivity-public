import { build } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { resolve } from "node:path";
import { readFile, writeFile, readdir, mkdir } from "node:fs/promises";
import { pack } from "../mobile-pack.mjs";

await build({
  configFile: false,
  // lib 模式下必须显式替换，否则产物里残留 process.env.NODE_ENV，浏览器报 "process is not defined" 直接白屏
  define: { "process.env.NODE_ENV": JSON.stringify("production") },
  plugins: [react(), tailwindcss()],
  resolve: { alias: { "@": resolve("src") } },
  build: {
    outDir: ".export/out",
    emptyOutDir: true,
    cssCodeSplit: false,
    target: "es2017", // 去掉 ?. / ?? / 正则 v 标志等，旧手机 WebView 也能解析
    lib: { entry: resolve(".export/entry.tsx"), name: "Kedu", formats: ["iife"], fileName: () => "app.js" },
    rollupOptions: { output: { inlineDynamicImports: true } },
  },
});

const dir = ".export/out";
const cssFile = (await readdir(dir)).find(x => x.endsWith(".css"));
const css = await readFile(`${dir}/${cssFile}`, "utf8");
const js = await readFile(`${dir}/app.js`, "utf8");
const html = pack(css, js); // process shim + CSS 降级 + 白屏兜底 + 移动端 meta

await mkdir("D:/codm/mobile", { recursive: true });
const targets = [
  "D:/codm/手感刻度-CODM.html",     // 原路径，原地修好
  "D:/codm/codm-sens.html",        // 纯 ASCII 文件名，方便微信/QQ 传到手机
  "D:/codm/mobile/index.html",     // 局域网 HTTP 服务根目录
];
await Promise.all(targets.map((p) => writeFile(p, html, "utf8")));
console.log("built:", (html.length / 1024).toFixed(1), "KB ->", targets.join(", "));
