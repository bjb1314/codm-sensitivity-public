import { createFileRoute } from "@tanstack/react-router";
import { SensApp } from "@/components/sens/SensApp";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <SensApp />;
}
