手感刻度 · 完整 TanStack Start 源码
================================

包含 src、scripts、server、public、migrations，以及 package.json、vite.config.ts、tsconfig.json。
不含 node_modules。

解压后：
  npm install
  npm run dev
